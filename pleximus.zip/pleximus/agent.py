import json
import time
import requests
from tools import TOOL_FUNCTIONS, TOOL_DECLARATIONS

# Kept short on purpose: every extra second here is a second the user stares
# at the "thinking" state, and every extra byte in a step payload is extra
# JSON the browser has to parse and paint in the Mind Inspector.
REQUEST_TIMEOUT_SECONDS = 12
MAX_TURNS = 4


class GeminiAgent:
    def __init__(self, api_key: str, model: str = "gemini-3.6-flash"):
        self.api_key = api_key
        self.model = model
        self.base_url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent"

    def run(self, prompt: str, chat_history=None) -> dict:
        """
        Runs the conversational loop with Gemini, executing tools until Gemini gives a final answer.
        Returns a dict with:
          - "response": final text reply from the agent.
          - "steps": a list of dictionary entries tracking the execution steps (kept lightweight).
          - "updated_history": the updated conversation history in Gemini API format.
          - "duration_ms": total wall-clock time the loop took.
        """
        start_time = time.monotonic()

        if chat_history is None:
            chat_history = []

        # Add the new user message to the history
        contents = list(chat_history)
        contents.append({
            "role": "user",
            "parts": [{"text": prompt}]
        })

        steps = []
        final_text = ""

        # Log the user prompt step
        steps.append({
            "step": "user_input",
            "title": "User Message Received",
            "detail": f"Prompt: '{prompt}'",
            "payload": prompt
        })

        for turn in range(MAX_TURNS):
            # Prepare payload for Gemini
            payload = {
                "contents": contents,
                "tools": [{"functionDeclarations": TOOL_DECLARATIONS}]
            }

            headers = {"Content-Type": "application/json"}
            url = f"{self.base_url}?key={self.api_key}"

            # NOTE: we deliberately do NOT log the full request payload here.
            # It contains the entire conversation history plus all 12 tool
            # declarations, which grows every turn and used to get re-sent
            # to the browser and re-rendered in full on every single step -
            # that repeated multi-KB JSON dump was the main source of a
            # slow-feeling response, not the network call itself.
            steps.append({
                "step": f"api_request_turn_{turn+1}",
                "title": f"Contacting Gemini API (Turn {turn+1})",
                "detail": f"Sending {len(contents)} message(s) with {len(TOOL_DECLARATIONS)} tool declarations.",
                "payload": {"message_count": len(contents), "tool_count": len(TOOL_DECLARATIONS), "model": self.model}
            })

            try:
                response = requests.post(url, json=payload, headers=headers, timeout=REQUEST_TIMEOUT_SECONDS)
                if response.status_code != 200:
                    error_msg = f"Gemini API returned status code {response.status_code}: {response.text}"
                    steps.append({
                        "step": "api_error",
                        "title": "API Request Failed",
                        "detail": error_msg,
                        "payload": response.text[:1500]
                    })
                    return {
                        "response": f"API Error: {response.text}",
                        "steps": steps,
                        "updated_history": contents,
                        "duration_ms": _elapsed_ms(start_time)
                    }

                res_json = response.json()

                candidate_preview = _summarize_candidate(res_json)
                steps.append({
                    "step": f"api_response_turn_{turn+1}",
                    "title": f"Gemini API Response Received (Turn {turn+1})",
                    "detail": "Received response candidates from the model.",
                    "payload": candidate_preview
                })

            except requests.exceptions.Timeout:
                error_msg = f"Gemini API did not respond within {REQUEST_TIMEOUT_SECONDS}s."
                steps.append({
                    "step": "connection_error",
                    "title": "Request Timed Out",
                    "detail": error_msg,
                    "payload": {}
                })
                return {
                    "response": f"Connection Error: {error_msg}",
                    "steps": steps,
                    "updated_history": contents,
                    "duration_ms": _elapsed_ms(start_time)
                }
            except Exception as e:
                error_msg = f"Failed to reach Gemini API: {str(e)}"
                steps.append({
                    "step": "connection_error",
                    "title": "Network Error",
                    "detail": error_msg,
                    "payload": str(e)
                })
                return {
                    "response": f"Connection Error: {error_msg}",
                    "steps": steps,
                    "updated_history": contents,
                    "duration_ms": _elapsed_ms(start_time)
                }

            candidates = res_json.get("candidates", [])
            if not candidates:
                msg = "No response candidates returned by Gemini."
                return {
                    "response": msg,
                    "steps": steps,
                    "updated_history": contents,
                    "duration_ms": _elapsed_ms(start_time)
                }

            candidate = candidates[0]
            content = candidate.get("content", {})
            parts = content.get("parts", [])

            # Check if there is a function call request
            function_calls = [p.get("functionCall") for p in parts if p.get("functionCall")]

            # Update history with the model's response structure
            contents.append(content)

            if function_calls:
                # We have a tool call to perform
                fn_call = function_calls[0]
                fn_name = fn_call.get("name")
                fn_args = fn_call.get("args", {})

                steps.append({
                    "step": "tool_execution_start",
                    "title": f"Tool Execution: {fn_name}",
                    "detail": f"Model decided to execute {fn_name} with arguments: {json.dumps(fn_args)}",
                    "payload": {"name": fn_name, "args": fn_args}
                })

                # Perform actual tool execution
                if fn_name in TOOL_FUNCTIONS:
                    try:
                        # Call tool function with unpacked parameters
                        tool_result = TOOL_FUNCTIONS[fn_name](**fn_args)
                        # Ensure output is wrapped correctly for Gemini
                        formatted_output = {"output": tool_result}
                    except Exception as e:
                        formatted_output = {"error": f"Internal execution crash: {str(e)}"}
                else:
                    formatted_output = {"error": f"Tool '{fn_name}' is not registered."}

                steps.append({
                    "step": "tool_execution_complete",
                    "title": f"Tool Execution Completed: {fn_name}",
                    "detail": "Tool output received. Forwarding back to Gemini.",
                    "payload": formatted_output
                })

                # Append the function response part to the contents for the next model turn
                contents.append({
                    "role": "user",
                    "parts": [{
                        "functionResponse": {
                            "name": fn_name,
                            "response": formatted_output
                        }
                    }]
                })

                # Proceed to next iteration of loop to send function output back to Gemini
                continue

            else:
                # No function call. The model has generated its final natural language answer!
                text_parts = [p.get("text", "") for p in parts if p.get("text")]
                final_text = "".join(text_parts)
                steps.append({
                    "step": "final_output",
                    "title": "Agent Formulating Response",
                    "detail": "No more tools needed. Formulating final natural language answer.",
                    "payload": final_text
                })
                break
        else:
            final_text = "The agent exceeded the maximum number of tool execution steps."
            steps.append({
                "step": "max_turns_exceeded",
                "title": "Turn Limit Reached",
                "detail": final_text,
                "payload": {}
            })

        return {
            "response": final_text,
            "steps": steps,
            "updated_history": contents,
            "duration_ms": _elapsed_ms(start_time)
        }


def _elapsed_ms(start_time: float) -> int:
    return int((time.monotonic() - start_time) * 1000)


def _summarize_candidate(res_json: dict) -> dict:
    """Keep only what the UI actually needs instead of the full raw response
    (usage metadata, safety ratings, etc.), so the payload stays small."""
    candidates = res_json.get("candidates", [])
    if not candidates:
        return {"candidates": 0}
    content = candidates[0].get("content", {})
    parts = content.get("parts", [])
    summary_parts = []
    for p in parts:
        if "functionCall" in p:
            summary_parts.append({"functionCall": p["functionCall"]})
        elif "text" in p:
            text = p["text"]
            summary_parts.append({"text": text[:500] + ("..." if len(text) > 500 else "")})
    usage = res_json.get("usageMetadata", {})
    return {
        "finish_reason": candidates[0].get("finishReason"),
        "parts": summary_parts,
        "token_usage": {
            "prompt": usage.get("promptTokenCount"),
            "response": usage.get("candidatesTokenCount"),
            "total": usage.get("totalTokenCount")
        }
    }
