import os
import json
import webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
from agent import GeminiAgent
import tools

PORT = 8000

def load_env():
    env_path = os.path.join(os.path.dirname(__file__), ".env")
    if os.path.exists(env_path):
        with open(env_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    parts = line.split("=", 1)
                    key = parts[0].strip()
                    val = parts[1].strip().strip('"').strip("'")
                    os.environ[key] = val

# Load environment variables on startup
load_env()

class AgentWorkspaceHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # Override to prevent clogging the console with standard HTTP requests
        pass

    def do_OPTIONS(self):
        # Set CORS headers
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        # Clean the path
        path = self.path.split("?")[0]
        
        if path == "/":
            self.serve_html_file("templates/index.html")
        elif path == "/api/tools":
            self.send_json(tools.TOOL_DECLARATIONS)
        elif path == "/api/todo":
            self.send_json({"tasks": tools.TODO_LIST})
        elif path == "/api/config":
            has_key = bool(os.environ.get("GEMINI_API_KEY"))
            self.send_json({"has_api_key": has_key, "default_model": "gemini-3.6-flash"})
        else:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"404 Not Found")

    def do_POST(self):
        # CORS preflight header
        content_length = int(self.headers.get("Content-Length", 0))
        post_data = self.rfile.read(content_length)
        
        path = self.path.split("?")[0]
        
        if path == "/api/chat":
            try:
                data = json.loads(post_data.decode("utf-8"))
                prompt = data.get("prompt", "")
                api_key = data.get("api_key", "").strip() or os.environ.get("GEMINI_API_KEY", "")
                model = data.get("model", "gemini-3.6-flash")
                history = data.get("history", [])
                
                if not api_key:
                    self.send_json_error("Google Gemini API Key is required to run the agent. Please configure it in System Config or .env.")
                    return
                
                # Instantiate agent and run the ReAct function calling loop
                agent = GeminiAgent(api_key=api_key, model=model)
                result = agent.run(prompt, chat_history=history)
                self.send_json(result)
            except Exception as e:
                self.send_json_error(f"Error handling agent loop: {str(e)}")
                
        elif path == "/api/todo":
            try:
                data = json.loads(post_data.decode("utf-8"))
                action = data.get("action", "")
                task_name = data.get("task_name", None)
                task_index = data.get("task_index", None)
                
                result = tools.manage_todo(action, task_name, task_index)
                self.send_json(result)
            except Exception as e:
                self.send_json_error(f"Error handling task: {str(e)}")
        else:
            self.send_response(404)
            self.end_headers()

    def serve_html_file(self, filepath):
        abs_path = os.path.join(os.path.dirname(__file__), filepath)
        if os.path.exists(abs_path):
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            with open(abs_path, "rb") as f:
                self.wfile.write(f.read())
        else:
            self.send_response(500)
            self.end_headers()
            self.wfile.write(f"Server Error: HTML file '{filepath}' is missing.".encode())

    def send_json(self, data):
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode("utf-8"))

    def send_json_error(self, error_message):
        self.send_response(400)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps({"error": error_message}).encode("utf-8"))


def run_server():
    server_address = ("", PORT)
    httpd = HTTPServer(server_address, AgentWorkspaceHandler)
    print(f"\n==================================================")
    print(f"PLEXIMUS AI AGENT WORKSPACE SERVER RUNNING!")
    print(f"URL: http://localhost:{PORT}")
    print(f"Press Ctrl+C to terminate the server.")
    print(f"==================================================\n")
    
    # Automatically open local browser tab
    try:
        webbrowser.open(f"http://localhost:{PORT}")
    except Exception:
        pass
        
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server...")
        httpd.server_close()

if __name__ == "__main__":
    run_server()
