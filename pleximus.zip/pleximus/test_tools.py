import unittest
import tools

class TestTools(unittest.TestCase):
    
    def test_calculate(self):
        # Basic arithmetic
        self.assertEqual(tools.calculate("2 + 2"), "4")
        self.assertEqual(tools.calculate("(10 * 5) - (20 / 4)"), "45.0")
        
        # Exponentiation
        self.assertEqual(tools.calculate("2 ** 10"), "1024")
        
        # Division by zero handling
        self.assertTrue("Division by zero" in tools.calculate("2 / 0"))
        
        # Security sanitization checks
        self.assertTrue("Error" in tools.calculate("import os; os.system('echo target')"))
        self.assertTrue("Error" in tools.calculate("eval('2+2')"))
        self.assertTrue("Error" in tools.calculate("__import__('os')"))
        
        # Overflow protection
        self.assertTrue("Error" in tools.calculate("2 ** 100000"))

    def test_text_utility(self):
        self.assertEqual(tools.text_utility("ratnagiri", "reverse"), {"result": "irigantar"})
        self.assertEqual(tools.text_utility("hello pleximus hackathon", "word_count"), {"result": 3})
        self.assertEqual(tools.text_utility("ai agent", "uppercase"), {"result": "AI AGENT"})
        self.assertEqual(tools.text_utility("WORKSPACE", "lowercase"), {"result": "workspace"})
        self.assertEqual(tools.text_utility("Hello World", "replace", "World", "Ratnagiri"), {"result": "Hello Ratnagiri"})
        
        # Parameter validation error handling
        self.assertTrue("error" in tools.text_utility("Hello", "replace"))

    def test_convert_unit(self):
        # Length
        self.assertAlmostEqual(tools.convert_unit(1, "km", "m")["result"], 1000.0)
        self.assertAlmostEqual(tools.convert_unit(12, "inch", "cm")["result"], 30.48)
        
        # Weight
        self.assertAlmostEqual(tools.convert_unit(1, "kg", "g")["result"], 1000.0)
        
        # Temperature
        self.assertAlmostEqual(tools.convert_unit(0, "celsius", "fahrenheit")["result"], 32.0)
        self.assertAlmostEqual(tools.convert_unit(100, "c", "f")["result"], 212.0)
        self.assertAlmostEqual(tools.convert_unit(300, "k", "c")["result"], 26.85)
        
        # Mismatched categories error handling
        self.assertTrue("error" in tools.convert_unit(10, "km", "kg"))
        self.assertTrue("error" in tools.convert_unit(10, "celsius", "mile"))

    def test_todo(self):
        # Clear database state
        tools.TODO_LIST.clear()
        
        # Add test
        res = tools.manage_todo("add", "Implement Voice Mode")
        self.assertEqual(len(res["tasks"]), 1)
        self.assertEqual(res["tasks"][0]["task"], "Implement Voice Mode")
        self.assertFalse(res["tasks"][0]["completed"])
        
        # Complete test
        res = tools.manage_todo("complete", task_index=0)
        self.assertTrue(res["tasks"][0]["completed"])
        
        # Delete test
        res = tools.manage_todo("delete", task_index=0)
        self.assertEqual(len(res["tasks"]), 0)

    def test_prime_and_fibonacci(self):
        # 13 is prime, and is in Fibonacci sequence (0, 1, 1, 2, 3, 5, 8, 13)
        res = tools.prime_and_fibonacci(13)
        self.assertTrue(res["is_prime"])
        self.assertTrue(res["is_fibonacci_number"])
        self.assertEqual(res["nth_fibonacci_value"], "233")  # F(13) = 233
        
        # 4 is not prime, and is not in Fibonacci sequence
        res = tools.prime_and_fibonacci(4)
        self.assertFalse(res["is_prime"])
        self.assertFalse(res["is_fibonacci_number"])
        
        # Negative / boundary validation
        self.assertTrue("error" in tools.prime_and_fibonacci(-1))
        self.assertTrue("error" in tools.prime_and_fibonacci(200000))

if __name__ == '__main__':
    unittest.main()
