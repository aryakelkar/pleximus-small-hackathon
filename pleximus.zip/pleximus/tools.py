import requests
import html
import datetime

# --- CORE TOOLS ---

def calculate(expression: str) -> str:
    """Evaluates mathematical expressions safely."""
    # Sanitization: allow only digits, operators, dots, parentheses, and spaces
    safe_chars = set("0123456789+-*/%(). ")
    if not all(c in safe_chars for c in expression):
        return "Error: Invalid characters in expression. Only numbers and basic operators are allowed."
        
    if "**" in expression:
        # Check exponent to prevent CPU hang
        parts = expression.split("**")
        try:
            exponent = float(parts[-1].strip().replace(")", "").replace("(", ""))
            if exponent > 1000:
                return "Error: Exponent is too large. Keep it under 1000 to prevent overflow."
        except Exception:
            pass
            
    try:
        # Evaluate math safely (no globals/locals access)
        result = eval(expression, {"__builtins__": None}, {})
        return str(result)
    except ZeroDivisionError:
        return "Error: Division by zero is not allowed."
    except Exception as e:
        return f"Error: Invalid mathematical expression ({str(e)})."


def get_weather(location: str) -> dict:
    """Fetches weather coordinates via geocoding, then gets current weather from Open-Meteo."""
    location = location.strip()
    try:
        # 1. Geocoding coordinates lookup
        geo_url = f"https://geocoding-api.open-meteo.com/v1/search?name={location}&count=1&language=en&format=json"
        geo_res = requests.get(geo_url, timeout=10)
        if geo_res.status_code != 200:
            return {"error": f"Geocoding API returned status code {geo_res.status_code}"}
            
        geo_data = geo_res.json()
        if not geo_data.get("results"):
            return {"error": f"Location '{location}' not found. Please try another city."}
            
        result = geo_data["results"][0]
        lat = result["latitude"]
        lon = result["longitude"]
        city_name = result.get("name", location)
        country = result.get("country", "")
        
        # 2. Weather forecast lookup
        weather_url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current_weather=true"
        w_res = requests.get(weather_url, timeout=10)
        if w_res.status_code != 200:
            return {"error": f"Weather API returned status code {w_res.status_code}"}
            
        w_data = w_res.json()
        current = w_data.get("current_weather", {})
        
        return {
            "location": f"{city_name}, {country}",
            "latitude": lat,
            "longitude": lon,
            "temperature": current.get("temperature"),
            "windspeed": current.get("windspeed"),
            "weathercode": current.get("weathercode"),
            "time": current.get("time")
        }
    except Exception as e:
        return {"error": f"Failed to retrieve weather: {str(e)}"}


def text_utility(text: str, action: str, replace_old: str = None, replace_new: str = None) -> dict:
    """Performs local text transformations."""
    action = action.lower().strip()
    if action == "reverse":
        return {"result": text[::-1]}
    elif action == "word_count":
        return {"result": len(text.split())}
    elif action == "char_count":
        return {"result": len(text)}
    elif action == "uppercase":
        return {"result": text.upper()}
    elif action == "lowercase":
        return {"result": text.lower()}
    elif action == "replace":
        if replace_old is None or replace_new is None:
            return {"error": "Parameters 'replace_old' and 'replace_new' are required for replace action."}
        return {"result": text.replace(replace_old, replace_new)}
    else:
        return {"error": f"Unknown action '{action}'. Supported: reverse, word_count, char_count, uppercase, lowercase, replace."}


# --- EXTENSION TOOLS ---

def github_repo_info(repo_name: str) -> dict:
    """Fetches key information about a GitHub repository."""
    repo_name = repo_name.strip()
    if "github.com/" in repo_name:
        repo_name = repo_name.split("github.com/")[-1]
    if repo_name.endswith(".git"):
        repo_name = repo_name[:-4]
    repo_name = repo_name.strip("/")
    
    parts = repo_name.split("/")
    if len(parts) < 2:
        return {"error": "Invalid format. Must be 'owner/repo_name' or a GitHub URL."}
    
    owner, repo = parts[0], parts[1]
    url = f"https://api.github.com/repos/{owner}/{repo}"
    headers = {"User-Agent": "PleximusHackathonAgent/1.0"}
    
    try:
        res = requests.get(url, headers=headers, timeout=10)
        if res.status_code == 404:
            return {"error": f"Repository '{owner}/{repo}' not found."}
        elif res.status_code != 200:
            return {"error": f"GitHub API returned error code {res.status_code}."}
        
        data = res.json()
        return {
            "name": data.get("name"),
            "full_name": data.get("full_name"),
            "description": data.get("description"),
            "stars": data.get("stargazers_count"),
            "forks": data.get("forks_count"),
            "language": data.get("language"),
            "open_issues": data.get("open_issues_count"),
            "license": data.get("license", {}).get("name") if data.get("license") else None,
            "url": data.get("html_url")
        }
    except Exception as e:
        return {"error": f"GitHub API connection failed: {str(e)}"}


def convert_unit(value: float, from_unit: str, to_unit: str) -> dict:
    """Converts weight, length, or temperature units."""
    from_unit = from_unit.lower().strip()
    to_unit = to_unit.lower().strip()
    
    length_factors = {
        "m": 1.0, "meter": 1.0, "meters": 1.0,
        "km": 1000.0, "kilometer": 1000.0, "kilometers": 1000.0,
        "mile": 1609.34, "miles": 1609.34,
        "yard": 0.9144, "yards": 0.9144,
        "foot": 0.3048, "feet": 0.3048,
        "inch": 0.0254, "inches": 0.0254,
        "cm": 0.01, "centimeter": 0.01, "centimeters": 0.01
    }
    
    weight_factors = {
        "kg": 1.0, "kilogram": 1.0, "kilograms": 1.0,
        "g": 0.001, "gram": 0.001, "grams": 0.001,
        "lb": 0.45359237, "pound": 0.45359237, "pounds": 0.45359237,
        "oz": 0.028349523, "ounce": 0.028349523, "ounces": 0.028349523
    }
    
    def convert_temp(val, f, t):
        if f in ["c", "celsius"]:
            k = val + 273.15
        elif f in ["f", "fahrenheit"]:
            k = (val - 32) * 5/9 + 273.15
        elif f in ["k", "kelvin"]:
            k = val
        else:
            return None
            
        if t in ["c", "celsius"]:
            return k - 273.15
        elif t in ["f", "fahrenheit"]:
            return (k - 273.15) * 9/5 + 32
        elif t in ["k", "kelvin"]:
            return k
        return None

    if from_unit in length_factors and to_unit in length_factors:
        val_in_m = value * length_factors[from_unit]
        converted = val_in_m / length_factors[to_unit]
        return {"result": converted, "unit": to_unit}
    elif from_unit in weight_factors and to_unit in weight_factors:
        val_in_kg = value * weight_factors[from_unit]
        converted = val_in_kg / weight_factors[to_unit]
        return {"result": converted, "unit": to_unit}
    elif from_unit in ["c", "celsius", "f", "fahrenheit", "k", "kelvin"] and to_unit in ["c", "celsius", "f", "fahrenheit", "k", "kelvin"]:
        converted = convert_temp(value, from_unit, to_unit)
        if converted is None:
            return {"error": f"Invalid temperature units: {from_unit} to {to_unit}"}
        return {"result": converted, "unit": to_unit}
    else:
        return {"error": f"Cannot convert between types: '{from_unit}' and '{to_unit}'."}


def currency_converter(amount: float, from_currency: str, to_currency: str) -> dict:
    """Converts values between fiat currencies using Frankfurter API."""
    from_currency = from_currency.upper().strip()
    to_currency = to_currency.upper().strip()
    if from_currency == to_currency:
        return {"result": amount, "rate": 1.0}
        
    url = f"https://api.frankfurter.dev/v1/latest?from={from_currency}&to={to_currency}"
    try:
        res = requests.get(url, timeout=10)
        if res.status_code != 200:
            return {"error": f"Currency API error: {res.text}"}
        data = res.json()
        rates = data.get("rates", {})
        if to_currency not in rates:
            return {"error": f"Target currency '{to_currency}' is not supported."}
        rate = rates[to_currency]
        return {
            "amount": amount,
            "from": from_currency,
            "to": to_currency,
            "rate": rate,
            "result": amount * rate,
            "date": data.get("date")
        }
    except Exception as e:
        return {"error": f"Failed to retrieve currency conversion: {str(e)}"}


def wikipedia_summary(title: str) -> dict:
    """Retrieves standard Wikipedia summary extracts."""
    title = title.strip().replace(" ", "_")
    url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{title}"
    headers = {"User-Agent": "PleximusHackathonAgent/1.0"}
    try:
        res = requests.get(url, headers=headers, timeout=10)
        if res.status_code == 404:
            return {"error": f"Wikipedia page '{title}' not found."}
        elif res.status_code != 200:
            return {"error": f"Wikipedia API returned code {res.status_code}."}
        data = res.json()
        return {
            "title": data.get("title"),
            "extract": data.get("extract"),
            "url": data.get("content_urls", {}).get("desktop", {}).get("page"),
            "thumbnail": data.get("thumbnail", {}).get("source")
        }
    except Exception as e:
        return {"error": f"Wikipedia fetch failed: {str(e)}"}


CITY_TIMEZONE_MAP = {
    "mumbai": "Asia/Kolkata", "kolkata": "Asia/Kolkata", "delhi": "Asia/Kolkata", 
    "bangalore": "Asia/Kolkata", "pune": "Asia/Kolkata", "ratnagiri": "Asia/Kolkata",
    "london": "Europe/London", "paris": "Europe/Paris", "berlin": "Europe/Berlin", 
    "tokyo": "Asia/Tokyo", "sydney": "Australia/Sydney", "singapore": "Asia/Singapore",
    "new york": "America/New_York", "ny": "America/New_York", "los angeles": "America/Los_Angeles", 
    "la": "America/Los_Angeles", "san francisco": "America/Los_Angeles", "sf": "America/Los_Angeles", 
    "chicago": "America/Chicago", "dubai": "Asia/Dubai", "utc": "UTC", "gmt": "GMT"
}

def get_current_time(timezone_or_city: str) -> dict:
    """Gets current date and time for a given city or timezone timezone ID."""
    tz = timezone_or_city.strip().lower()
    timezone_id = CITY_TIMEZONE_MAP.get(tz)
    
    if not timezone_id:
        if "/" in timezone_or_city:
            timezone_id = timezone_or_city.strip()
        else:
            timezone_id = timezone_or_city.strip().replace(" ", "_").title()
            
    url = f"https://timeapi.io/api/time/current/zone?timeZone={timezone_id}"
    try:
        res = requests.get(url, timeout=10)
        if res.status_code != 200:
            raise Exception("API failure")
        data = res.json()
        return {
            "timezone": data.get("timeZone"),
            "dateTime": data.get("dateTime"),
            "time": data.get("time"),
            "date": data.get("date"),
            "dayOfWeek": data.get("dayOfWeek")
        }
    except Exception as e:
        now = datetime.datetime.now()
        return {
            "timezone": "Local Machine (Fallback)",
            "dateTime": now.strftime("%Y-%m-%d %H:%M:%S"),
            "time": now.strftime("%H:%M:%S"),
            "date": now.strftime("%Y-%m-%d"),
            "dayOfWeek": now.strftime("%A"),
            "warning": f"Timezone API failed, fell back to local system time. ({str(e)})"
        }


# Stateful in-memory todo store
TODO_LIST = []

def manage_todo(action: str, task_name: str = None, task_index: int = None) -> dict:
    """Manages an in-memory To-Do list (add, list, complete, delete)."""
    global TODO_LIST
    action = action.lower().strip()
    
    if action == "add":
        if not task_name:
            return {"error": "Task name is required to add.", "tasks": TODO_LIST}
        TODO_LIST.append({"task": task_name, "completed": False})
        return {"message": f"Added task: '{task_name}'", "tasks": TODO_LIST}
        
    elif action == "list":
        return {"tasks": TODO_LIST}
        
    elif action == "complete":
        if task_index is None:
            if task_name:
                for task in TODO_LIST:
                    if task_name.lower() in task["task"].lower():
                        task["completed"] = True
                        return {"message": f"Completed task: '{task['task']}'", "tasks": TODO_LIST}
            return {"error": "Provide task name or index.", "tasks": TODO_LIST}
        try:
            idx = int(task_index)
            if 0 <= idx < len(TODO_LIST):
                TODO_LIST[idx]["completed"] = True
                return {"message": f"Completed task: '{TODO_LIST[idx]['task']}'", "tasks": TODO_LIST}
            return {"error": "Index out of range.", "tasks": TODO_LIST}
        except ValueError:
            return {"error": "Index must be an integer.", "tasks": TODO_LIST}
            
    elif action == "delete":
        if task_index is None:
            if task_name:
                for idx, task in enumerate(TODO_LIST):
                    if task_name.lower() in task["task"].lower():
                        deleted = TODO_LIST.pop(idx)
                        return {"message": f"Deleted task: '{deleted['task']}'", "tasks": TODO_LIST}
            return {"error": "Provide task name or index.", "tasks": TODO_LIST}
        try:
            idx = int(task_index)
            if 0 <= idx < len(TODO_LIST):
                deleted = TODO_LIST.pop(idx)
                return {"message": f"Deleted task: '{deleted['task']}'", "tasks": TODO_LIST}
            return {"error": "Index out of range.", "tasks": TODO_LIST}
        except ValueError:
            return {"error": "Index must be an integer.", "tasks": TODO_LIST}
    else:
        return {"error": f"Invalid action '{action}'. Use add, list, complete, delete.", "tasks": TODO_LIST}


def prime_and_fibonacci(number: int) -> dict:
    """Checks if a number is prime and if it is part of the Fibonacci sequence."""
    try:
        n = int(number)
    except Exception:
        return {"error": "Input must be an integer."}
        
    if n < 0 or n > 100000:
        return {"error": "Number must be between 0 and 100,000."}
        
    # Prime check
    is_prime = True
    if n < 2:
        is_prime = False
    else:
        for i in range(2, int(n**0.5) + 1):
            if n % i == 0:
                is_prime = False
                break
                
    # Fibonacci membership check: 5*n^2 +/- 4 is perfect square
    def is_square(x):
        s = int(x**0.5)
        return s*s == x
        
    is_fib = is_square(5*n*n + 4) or is_square(5*n*n - 4)
    
    # N-th Fibonacci calculation up to index 1000
    fib_n = None
    if 0 <= n <= 1000:
        a, b = 0, 1
        for _ in range(n):
            a, b = b, a + b
        fib_n = a
        
    return {
        "number": n,
        "is_prime": is_prime,
        "is_fibonacci_number": is_fib,
        "nth_fibonacci_value": str(fib_n) if fib_n is not None else "Out of bounds (>1000)"
    }


def fetch_trivia_or_joke(category: str) -> dict:
    """Fetches trivia from OpenTDB or joke from icanhazdadjoke."""
    category = category.lower().strip()
    if "trivia" in category:
        url = "https://opentdb.com/api.php?amount=1"
        try:
            res = requests.get(url, timeout=10)
            if res.status_code != 200:
                return {"error": "Trivia API rate-limited or error."}
            data = res.json()
            results = data.get("results", [])
            if not results:
                return {"error": "No trivia questions returned."}
            item = results[0]
            return {
                "type": "trivia",
                "category": item.get("category"),
                "difficulty": item.get("difficulty"),
                "question": html.unescape(item.get("question", "")),
                "correct_answer": html.unescape(item.get("correct_answer", "")),
                "options": [html.unescape(o) for o in item.get("incorrect_answers", [])] + [html.unescape(item.get("correct_answer", ""))]
            }
        except Exception as e:
            return {"error": f"Failed to load trivia: {str(e)}"}
    else:
        url = "https://icanhazdadjoke.com"
        headers = {"Accept": "application/json", "User-Agent": "PleximusHackathonAgent/1.0"}
        try:
            res = requests.get(url, headers=headers, timeout=10)
            if res.status_code != 200:
                return {"error": "Joke API error."}
            data = res.json()
            return {
                "type": "joke",
                "joke": data.get("joke")
            }
        except Exception as e:
            return {"error": f"Failed to load joke: {str(e)}"}


def duckduckgo_search(query: str) -> dict:
    """DuckDuckGo Instant Answer search engine query."""
    query = query.strip()
    url = f"https://api.duckduckgo.com/?q={query}&format=json"
    headers = {"User-Agent": "PleximusHackathonAgent/1.0"}
    try:
        res = requests.get(url, headers=headers, timeout=10)
        if res.status_code != 200:
            return {"error": f"DuckDuckGo API error code {res.status_code}"}
        data = res.json()
        
        abstract = data.get("AbstractText", "")
        abstract_src = data.get("AbstractSource", "")
        abstract_url = data.get("AbstractURL", "")
        
        topics = []
        for t in data.get("RelatedTopics", [])[:3]:
            if "Text" in t:
                topics.append({"text": t.get("Text"), "url": t.get("FirstURL")})
                
        return {
            "query": query,
            "abstract": abstract,
            "source": abstract_src,
            "url": abstract_url,
            "related_topics": topics,
            "note": "Only well-known entities return results here. Use precise nouns." if not abstract else "Success"
        }
    except Exception as e:
        return {"error": f"DuckDuckGo query failed: {str(e)}"}


# --- TOOL REGISTRY ---

# Maps function names to Python functions and declarations for Gemini API

TOOL_FUNCTIONS = {
    "calculate": calculate,
    "get_weather": get_weather,
    "text_utility": text_utility,
    "github_repo_info": github_repo_info,
    "convert_unit": convert_unit,
    "currency_converter": currency_converter,
    "wikipedia_summary": wikipedia_summary,
    "get_current_time": get_current_time,
    "manage_todo": manage_todo,
    "prime_and_fibonacci": prime_and_fibonacci,
    "fetch_trivia_or_joke": fetch_trivia_or_joke,
    "duckduckgo_search": duckduckgo_search
}

TOOL_DECLARATIONS = [
    {
        "name": "calculate",
        "description": "Evaluate basic arithmetic mathematical expressions safely. Supports +, -, *, /, %, **, parentheses. Example: '(45 * 2) + (100 / 5)'.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "expression": {
                    "type": "STRING",
                    "description": "The math expression to solve, e.g. '123 + 456 * 2'."
                }
            },
            "required": ["expression"]
        }
    },
    {
        "name": "get_weather",
        "description": "Fetches current weather information for any given location city name (e.g. 'Ratnagiri', 'Mumbai', 'London').",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "location": {
                    "type": "STRING",
                    "description": "The city/town name, e.g. 'Ratnagiri'."
                }
            },
            "required": ["location"]
        }
    },
    {
        "name": "text_utility",
        "description": "Utility for text/string manipulation (reverse, word count, character count, uppercase, lowercase, replace).",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "text": {
                    "type": "STRING",
                    "description": "The source text string to operate on."
                },
                "action": {
                    "type": "STRING",
                    "description": "Action to run: 'reverse', 'word_count', 'char_count', 'uppercase', 'lowercase', or 'replace'."
                },
                "replace_old": {
                    "type": "STRING",
                    "description": "Substring to search for when action is 'replace' (optional)."
                },
                "replace_new": {
                    "type": "STRING",
                    "description": "Replacement substring when action is 'replace' (optional)."
                }
            },
            "required": ["text", "action"]
        }
    },
    {
        "name": "github_repo_info",
        "description": "Fetch repo description, stars, forks, language, and license for any public GitHub repository.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "repo_name": {
                    "type": "STRING",
                    "description": "Repo string as 'owner/repo' or URL, e.g. 'google/jax' or 'https://github.com/google/jax'."
                }
            },
            "required": ["repo_name"]
        }
    },
    {
        "name": "convert_unit",
        "description": "Converts units of length (m, km, mile, yard, foot, inch, cm), weight (kg, g, lb, oz), or temperature (c, f, k).",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "value": {
                    "type": "NUMBER",
                    "description": "Numerical value to convert."
                },
                "from_unit": {
                    "type": "STRING",
                    "description": "Source unit, e.g. 'celsius', 'kg', 'mile'."
                },
                "to_unit": {
                    "type": "STRING",
                    "description": "Target unit, e.g. 'fahrenheit', 'lb', 'km'."
                }
            },
            "required": ["value", "from_unit", "to_unit"]
        }
    },
    {
        "name": "currency_converter",
        "description": "Converts amounts between global currencies using real-time Frankfurter exchange rates.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "amount": {
                    "type": "NUMBER",
                    "description": "The money amount to convert."
                },
                "from_currency": {
                    "type": "STRING",
                    "description": "Three-letter code of source currency, e.g. 'USD'."
                },
                "to_currency": {
                    "type": "STRING",
                    "description": "Three-letter code of target currency, e.g. 'INR'."
                }
            },
            "required": ["amount", "from_currency", "to_currency"]
        }
    },
    {
        "name": "wikipedia_summary",
        "description": "Retrieves the main summary extract of a given topic/title from Wikipedia.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "title": {
                    "type": "STRING",
                    "description": "Topic or title of Wikipedia article, e.g. 'Artificial intelligence'."
                }
            },
            "required": ["title"]
        }
    },
    {
        "name": "get_current_time",
        "description": "Get current time, date, and day of the week for a city or timezone region (e.g. 'Asia/Kolkata', 'Europe/London', or 'New York').",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "timezone_or_city": {
                    "type": "STRING",
                    "description": "Timezone string or city, e.g. 'Asia/Kolkata', 'Tokyo', 'America/New_York'."
                }
            },
            "required": ["timezone_or_city"]
        }
    },
    {
        "name": "manage_todo",
        "description": "Stateful todo checklist manager. Can add tasks, list tasks, complete them, or delete them in-memory.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {
                    "type": "STRING",
                    "description": "Action to perform: 'add', 'list', 'complete', or 'delete'."
                },
                "task_name": {
                    "type": "STRING",
                    "description": "The title text of the task (required for 'add', optional search for 'complete'/'delete')."
                },
                "task_index": {
                    "type": "NUMBER",
                    "description": "0-based numerical index of the task (useful for 'complete' or 'delete')."
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "prime_and_fibonacci",
        "description": "Checks if a number is prime and a Fibonacci number, and computes the N-th Fibonacci sequence value.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "number": {
                    "type": "INTEGER",
                    "description": "An integer between 0 and 100000."
                }
            },
            "required": ["number"]
        }
    },
    {
        "name": "fetch_trivia_or_joke",
        "description": "Fetches a funny dad joke or a random multiple-choice general knowledge trivia question.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "category": {
                    "type": "STRING",
                    "description": "Specify 'joke' or 'trivia' to fetch."
                }
            },
            "required": ["category"]
        }
    },
    {
        "name": "duckduckgo_search",
        "description": "Searches DuckDuckGo Instant Answer API for quick summaries of a well-known entity or topic (person, place, company, concept).",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {
                    "type": "STRING",
                    "description": "Topic to search, e.g. 'Python programming'."
                }
            },
            "required": ["query"]
        }
    }
]
